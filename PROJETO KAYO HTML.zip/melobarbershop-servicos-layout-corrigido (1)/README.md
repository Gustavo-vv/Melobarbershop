# Melo Barber Shop — versão melhorada

Landing page responsiva para a Melo Barber Shop.

## Estrutura
- `index.html` — estrutura e conteúdo da página
- `css/style.css` — estilos principais
- `css/media.css` — responsividade
- `js/script.js` — menu mobile e galeria lightbox
- `img/` — imagens e ícones; substitua os arquivos mantendo os nomes para trocar as fotos sem alterar o HTML

## Personalização rápida
1. Troque as imagens dentro de `img/`.
2. Para alterar o WhatsApp, procure por `5511966470949` no `index.html`.
3. Para colocar o Instagram oficial, altere o `href="#"` do link do Instagram no rodapé.
4. Para alterar preços, edite os valores nos cards de serviços.

## Observação
Os valores de serviços que não estavam definidos no projeto original foram marcados como `Consulte`, evitando inventar preços. O combo Corte + Barba foi apresentado como R$ 90,00 apenas como referência visual e deve ser ajustado se esse não for o preço real.
