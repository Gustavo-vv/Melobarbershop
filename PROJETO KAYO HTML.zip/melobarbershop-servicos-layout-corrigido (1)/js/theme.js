(function () {
    const STORAGE_KEY = 'melo-theme';
    const root = document.documentElement;
    const saved = localStorage.getItem(STORAGE_KEY);
    const initial = saved === 'light' || saved === 'dark' ? saved : 'dark';

    function updateButton(button, theme) {
        if (!button) return;
        const light = theme === 'light';
        button.setAttribute('aria-label', light ? 'Tema escuro' : 'Tema claro');
        button.title = light ? 'Tema escuro' : 'Tema claro';
        const icon = button.querySelector('.theme-toggle-icon');
        const label = button.querySelector('.theme-toggle-label');
        if (icon) icon.textContent = light ? '☾' : '☀';
        if (label) label.textContent = light ? 'Tema escuro' : 'Tema claro';
    }

    function applyTheme(theme) {
        theme = theme === 'light' ? 'light' : 'dark';
        root.setAttribute('data-theme', theme);
        localStorage.setItem(STORAGE_KEY, theme);
        document.querySelectorAll('.theme-toggle').forEach(btn => updateButton(btn, theme));
    }

    root.setAttribute('data-theme', initial);

    document.addEventListener('DOMContentLoaded', function () {
        const serviceButton = document.querySelector('#serviceThemeToggle');
        if (serviceButton) {
            serviceButton.addEventListener('click', function () {
                const current = root.getAttribute('data-theme') || 'dark';
                applyTheme(current === 'dark' ? 'light' : 'dark');
            });
            applyTheme(root.getAttribute('data-theme'));
            return;
        }

        const existing = document.querySelector('.theme-toggle');
        if (existing) {
            existing.addEventListener('click', function () {
                const current = root.getAttribute('data-theme') || 'dark';
                applyTheme(current === 'dark' ? 'light' : 'dark');
            });
            applyTheme(root.getAttribute('data-theme'));
            return;
        }

        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'theme-toggle';
        button.innerHTML = '<span class="theme-toggle-icon" aria-hidden="true"></span><span class="theme-toggle-label"></span>';
        button.addEventListener('click', function () {
            const current = root.getAttribute('data-theme') || 'dark';
            applyTheme(current === 'dark' ? 'light' : 'dark');
        });

        document.body.appendChild(button);
        applyTheme(root.getAttribute('data-theme'));
    });
})();
